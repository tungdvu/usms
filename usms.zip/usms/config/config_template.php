<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['template_f'] = '';
$config['template_default'] = 'template/default/';