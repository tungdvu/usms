<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['data'] = array (
 'adzone' => array(
	   '0' => array(
		'name' => '-- Chọn vùng hiển thị --'
	   ),
	   'top1' => array(
		'name' => 'Baner quảng cáo top 1'
	   ),
	   'top2' => array(
		'name' => 'Baner quảng cáo top 2'
	   ),
	   'top3' => array(
		'name' => 'Baner quảng cáo top 3'
	   ),
	   'top4' => array(
		'name' => 'Baner quảng cáo top 4'
	   ),
	   'top5' => array(
		'name' => 'Baner quảng cáo top 5'
	   )
 )
);