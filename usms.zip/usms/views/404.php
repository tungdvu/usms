</div>
<div class="post error404 full-width">
	<div class="post-inner">
   		<div class="title-404" style="font-family: 'Droid Sans',Arial,Verdana,sans-serif;text-align:center">404 :(</div> 
   		<h2 class="post-title" style="font-family: BebasNeueRegular,arial,Georgia,serif;text-align:center">Not Found</h2>
	   	<div class="entry">
	   		<p style="text-align:center">Trang bạn yêu cầu không tồn tại hoặc đã bị xóa!</p>
	   		<div class="search-block-large">
	   			<center><button id="goBack" type="button" style="background-color: #F88C00; color: #fff; border-radius: 4px;">Quay Lại Trang Trước</button></center>
	   		</div>
	    </div>
    </div>
</div>
<script>
$('#goBack').click(function(event) {
	window.history.back();
});
window.document.title = '404 Page Not Found - Không Tìm Thấy Trang';
</script>
<div>