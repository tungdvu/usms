<?php  
/**
 * USMS - He thong quan ly khoa hoc cong nghe (UTT)
 * version 1.0
 * @author TungVu
 * @email  tungnv249@gmail.com
 * @url    facebook.com/mr.tungnv
 * 09/01/2017
 */
  ?>
<!-- Footer -->  
<footer id="footer"> 
	<div class="container"> 
		<div class="text-center"> 
			<p>Bản quyền &copy; 2016 - <a href="http://utt.edu.vn">Trường Đại học Công nghệ Giao thông vận tải</a> | Tel: 043.8544264</p> 
		</div> 
	</div> 
</footer> <!--/#footer--> 