<?php
/**
 * USMS - He thong quan ly khoa hoc cong nghe (UTT)
 * v 1.0
 * @author TungVu
 * @email  tungnv249@gmail.com
 * @url    facebook.com/mr.tungnv
 */
?>

<!-- Page -->
<div class="page">
<div class="page-content container-fluid">
  <div class="row" data-plugin="matchHeight" data-by-row="true">
    <div class="col-lg-12">
    <h1>Thông tin tài khoản</h1>
      <!-- Begin Content -->


      <!-- End Content -->
    </div>
  </div>
</div>
</div>
<!-- End Page -->