<?php  
/**
 * USMS - He thong quan ly khoa hoc cong nghe (UTT)
 * version 1.0
 * @author TungVu
 * @email  tungnv249@gmail.com
 * @url    facebook.com/mr.tungnv
 */
  ?>
<!-- Footer -->  
<footer class="site-footer">
<div class="site-footer-legal">© 2016 <a href="http://utt.edu.vn">USMS - Hệ thống Quản lý hoạt động Khoa học công nghệ</a></div>
  	<div class="site-footer-right">
  		Ver 1.0 <i class="red-600 icon md-favorite"></i> by <a href="http://facebook.com/mr.tungnv">Trung tâm CNTT</a>
  	</div>
</footer>