<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$lang['home_lang'] = array();
$lang['home_lang']['title'] = 'Title';